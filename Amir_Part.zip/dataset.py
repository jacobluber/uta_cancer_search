import os
from pickle import NONE
import torch
from torch.utils.data import Dataset, DataLoader
from PIL import Image
from torch import nn
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import image
from skimage import io, transform
from torchvision import transforms, utils
import torch.nn as nn
import random
from sklearn.model_selection import train_test_split



def unpickle(file):
    import pickle
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict

class array_to_tensor:

  def __call__(self,images):

     images=torch.from_numpy(images)
     images=images.permute(2,0,1)
     images=images[None,:, :,:]

     return images



class stl10_Dataset():
    def __init__(self,root,train,transform=None):
       
       self.images_adresses=[]
       self.root=root
       self.transform=transform
       self.train=train
        
       for file in os.listdir(self.root):
         
         for image in os.listdir(os.path.join(self.root, file)):
            self.images_adresses.append((os.path.join(self.root, file,image).replace("\\","/")))

       #self.images_adresses=set(self.images_adresses)
       
       #self.train_images_adresses= set(random.sample(self.images_adresses, 4500))
       #self.test_images_adresses= self.images_adresses - self.train_images_adresses
       #self.train_images_adresses=list(self.train_images_adresses)
       #self.test_images_adresses=list(self.test_images_adresses)


       self.train_images_adresses, self.test_images_adresses = train_test_split(self.images_adresses, test_size=0.1, random_state=11)
       


       




   


    def __len__(self):
      if self.train:
       return len(self.train_images_adresses)
      
      else:
       return len(self.test_images_adresses)

      

    def __getitem__(self,index):


      if self.train:
      #image= np.array(Image.fromarray(self.images_adresses[index]).resize((64, 64), Image.ANTIALIAS))
         image= np.array(Image.open(self.train_images_adresses[index]).resize((64, 64), Image.ANTIALIAS))
        
         mean=np.mean(image,axis=tuple(range(image.ndim-1)))
         std=np.std(image,axis=tuple(range(image.ndim-1)))

         ch1=(image[:,:,0]-mean[0])/std[0]
         ch2=(image[:,:,1]-mean[1])/std[1]
         ch3=(image[:,:,2]-mean[2])/std[2]

         normalized_image= np.dstack((ch1,ch2,ch3))
         
         
         
      #image=io.imread(self.images_adresses[index])

      else:
         image= np.array(Image.open(self.test_images_adresses[index]).resize((64, 64), Image.ANTIALIAS))

         mean=np.mean(image,axis=tuple(range(image.ndim-1)))
         std=np.std(image,axis=tuple(range(image.ndim-1)))

         ch1=(image[:,:,0]-mean[0])/std[0]
         ch2=(image[:,:,1]-mean[1])/std[1]
         ch3=(image[:,:,2]-mean[2])/std[2]

         normalized_image= np.dstack((ch1,ch2,ch3))


         #print(type(normalized_image))
      
    
      if self.transform is not None:
        normalized_image=self.transform(normalized_image)
        normalized_image=(normalized_image).float()
        

      return normalized_image

class cifar10_Dataset:
    def __init__(self,root,transform=None):

       self.root=root
       self.transform=transform
       
       L=[]

       for file in os.listdir(self.root):

           data=unpickle(os.path.join(self.root,file).replace("\\","/"))[b'data']
           L.append(data)
        
       self.images_matrix=np.concatenate((L[0],L[1],L[2],L[3],L[4],L[5]),axis=0)
       self.images_matrix=self.images_matrix.reshape(self.images_matrix.shape[0],32,32,3)

       self.train_images_matrix,self.test_images_matrix= train_test_split(self.images_matrix, test_size=0.1, random_state=11)



       

    def __len__(self):
      if self.train:
       return len(self.train_images_matrix)
      
      else:
       return len(self.test_images_matrix)

    def __getitem__(self,index):


      if self.train:
      #image= np.array(Image.fromarray(self.images_adresses[index]).resize((64, 64), Image.ANTIALIAS))
         image= np.array(Image.open(self.train_images_adresses[index]).resize((64, 64), Image.ANTIALIAS))
        
         mean=np.mean(image,axis=tuple(range(image.ndim-1)))
         std=np.std(image,axis=tuple(range(image.ndim-1)))

         ch1=(image[:,:,0]-mean[0])/std[0]
         ch2=(image[:,:,1]-mean[1])/std[1]
         ch3=(image[:,:,2]-mean[2])/std[2]

         normalized_image= np.dstack((ch1,ch2,ch3))
         
         
         
      #image=io.imread(self.images_adresses[index])

      else:
         image= np.array(Image.open(self.test_images_adresses[index]).resize((64, 64), Image.ANTIALIAS))

         mean=np.mean(image,axis=tuple(range(image.ndim-1)))
         std=np.std(image,axis=tuple(range(image.ndim-1)))

         ch1=(image[:,:,0]-mean[0])/std[0]
         ch2=(image[:,:,1]-mean[1])/std[1]
         ch3=(image[:,:,2]-mean[2])/std[2]

         normalized_image= np.dstack((ch1,ch2,ch3))


         #print(type(normalized_image))
      
    
      if self.transform is not None:
        normalized_image=self.transform(normalized_image)
        normalized_image=(normalized_image).float()
        

      return normalized_image

      image=self.images_matrix[index]

      if self.transform is not None:
          image=self.transform(image)

      return image




#######################result for stl_dataset###################

#transform=transforms.Compose([array_to_tensor()])

#transform=transforms.Compose([transforms.ToTensor()])
#root1='/home/data/stl_10/img'
#dataset1=stl10_Dataset(root=root1,transform=transform)

#print(len(dataset1))





#root2='/home/data/cifar10/cifar10data'
#dataset2=cifar10_Dataset(root=root2,transform=transform)
